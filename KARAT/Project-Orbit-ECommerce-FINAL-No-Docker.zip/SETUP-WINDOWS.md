# Project Orbit — Windows setup

## Required software

1. JDK 17 or newer. JDK 21 is supported.
2. Maven 3.8+.
3. Node.js 20+.
4. VS Code.

Docker and PostgreSQL are **not required** for this version.

## Start backend

Open VS Code terminal 1:

```powershell
cd backend
mvn clean spring-boot:run
```

Keep this terminal running.

## Start frontend

Open VS Code terminal 2:

```powershell
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Quick health check

Open:

`http://localhost:8080/api/products`

You should see a JSON list containing the seeded products.

## Admin

`admin@orbit.com`

`Admin@123`

## H2 database

The application uses an in-memory H2 database. It is automatically created and seeded when Spring Boot starts. Restarting the backend resets the database.

H2 Console:

`http://localhost:8080/h2-console`

JDBC URL: `jdbc:h2:mem:orbitdb`

User: `sa`

Password: blank
