# Project Orbit — E-Commerce Portal

A runnable full-stack training project based on the supplied Project Orbit specification.

## Important: no Docker / no PostgreSQL required

This final version uses an **embedded H2 database in memory** by default. You do not need Docker, PostgreSQL, or any database installation to run it.

The database is recreated each time the backend starts, and the seed data is inserted automatically.

## Requirements on Windows

- Java JDK 17 or newer (Java 21 is also fine)
- Maven 3.8+ (`mvn -version`)
- Node.js 20+ and npm
- VS Code

## 1. Start the backend

Open a VS Code terminal:

```powershell
cd backend
mvn clean spring-boot:run
```

Backend URL:

`http://localhost:8080`

You should see:

`Started OrbitEcommerceApplication`

## 2. Start the frontend

Open a second VS Code terminal:

```powershell
cd frontend
npm install
npm run dev
```

Open:

`http://localhost:5173`

## Default admin account

Email: `admin@orbit.com`

Password: `Admin@123`

## Customer flow

1. Register a customer at `/register`.
2. Login.
3. Browse `/products`.
4. Open a product and add it to cart.
5. Open `/cart`.
6. Place the order.
7. Check `/orders`.
8. Open the order details.
9. Payment is simulated with a mock payment and returns `SUCCESS`.
10. Login as admin in a separate browser session when you want to test admin operations.

## Admin flow

1. Login with the admin account.
2. Open `/admin`.
3. View all orders.
4. Change order status through the lifecycle:
   `CREATED -> CONFIRMED -> PROCESSING -> SHIPPED -> DELIVERED`
5. Test product creation/update/activation/deactivation.
6. Test inventory changes.
7. Test invalid order status transitions.
8. Test payment refund.

## API base URL

`http://localhost:8080`

Protected endpoints require:

`Authorization: Bearer <JWT>`

### Authentication

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`

### Products

- `GET /api/products`
- `GET /api/products/{id}`
- `GET /api/products/search?q=laptop`
- `GET /api/products/category/Electronics`
- `POST /api/products` — ADMIN
- `PUT /api/products/{id}` — ADMIN
- `DELETE /api/products/{id}` — ADMIN
- `PATCH /api/products/{id}/activate` — ADMIN
- `PATCH /api/products/{id}/deactivate` — ADMIN

### Orders

- `POST /api/orders`
- `GET /api/orders`
- `GET /api/orders/{id}`
- `PATCH /api/orders/{id}/cancel`

### Admin orders

- `GET /api/admin/orders`
- `GET /api/admin/orders/status/{status}`
- `PATCH /api/admin/orders/{id}/status`

### Inventory

- `GET /api/inventory`
- `GET /api/inventory/{id}`
- `POST /api/inventory?productId=1`
- `PUT /api/inventory/{id}`
- `PATCH /api/inventory/{id}/increase`
- `PATCH /api/inventory/{id}/decrease`

### Payment

- `POST /api/payments`
- `GET /api/payments/{id}`
- `GET /api/orders/{orderId}/payment`
- `POST /api/payments/{id}/refund` — ADMIN

### Notification

- `POST /api/notifications`
- `GET /api/notifications/{id}`
- `GET /api/notifications/user/{userId}`

## Postman

Import:

`postman/Project-Orbit.postman_collection.json`

A convenient API test order is:

1. Register
2. Login
3. Copy JWT
4. GET products
5. Create order
6. Create payment
7. Get orders
8. Login as admin
9. Get admin orders
10. Change status
11. Change inventory
12. Refund payment

## H2 console

While the backend is running, H2 Console is available at:

`http://localhost:8080/h2-console`

Use:

- JDBC URL: `jdbc:h2:mem:orbitdb`
- User: `sa`
- Password: leave blank

## Notes

- Cart data is stored in browser localStorage because the supplied API catalogue has no Cart endpoint.
- Payment is intentionally mock/simulated for training.
- The default database is H2 so the project works on company laptops where Docker/PostgreSQL installation is restricted.
