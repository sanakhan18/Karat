import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <section className="hero">
      <small>PROJECT ORBIT</small>
      <h1>Full-stack E-Commerce Portal</h1>
      <p>Spring Boot + H2 + JWT + React.</p>
      <Link className="cta" to="/products">Shop Products</Link>
    </section>
  );
}
