package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.model.*;
import com.orbit.ecommerce.service.*;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/admin/orders") public class AdminController{
    final OrderService s;
    public AdminController(OrderService s){
        this.s=s;
    }
    @GetMapping public List<OrderOut> all(){
        return s.all();
    }
    @GetMapping("/status/{status}") public List<OrderOut> by(@PathVariable OrderStatus status){
        return s.by(status);
    }
    @PatchMapping("/{id}/status") public OrderOut status(@PathVariable Long id,@Valid @RequestBody StatusReq x){
        return s.status(id,x.status());
    }
}
