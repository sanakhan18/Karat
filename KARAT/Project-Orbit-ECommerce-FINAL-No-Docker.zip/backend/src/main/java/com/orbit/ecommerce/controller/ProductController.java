package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/products") public class ProductController{
    final ProductService s;
    public ProductController(ProductService s){
        this.s=s;
    }
    @GetMapping public List<ProductOut> all(){
        return s.all();
    }
    @GetMapping("/search") public List<ProductOut> search(@RequestParam String q){
        return s.search(q);
    }
    @GetMapping("/category/{c}") public List<ProductOut> cat(@PathVariable String c){
        return s.cat(c);
    }
    @GetMapping("/{id}") public ProductOut one(@PathVariable Long id){
        return s.one(id);
    }
    @PostMapping public ProductOut create(@Valid @RequestBody ProductReq x){
        return s.create(x);
    }
    @PutMapping("/{id}") public ProductOut update(@PathVariable Long id,@Valid @RequestBody ProductReq x){
        return s.update(id,x);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){
        s.delete(id);
    }
    @PatchMapping("/{id}/activate") public ProductOut a(@PathVariable Long id){
        return s.active(id,true);
    }
    @PatchMapping("/{id}/deactivate") public ProductOut d(@PathVariable Long id){
        return s.active(id,false);
    }
}
