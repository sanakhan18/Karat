package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/orders") public class OrderController{
    final OrderService s;
    public OrderController(OrderService s){
        this.s=s;
    }
    @PostMapping public OrderOut create(Authentication a,@Valid @RequestBody OrderReq x){
        return s.create(a.getName(),x);
    }
    @GetMapping public List<OrderOut> mine(Authentication a){
        return s.mine(a.getName());
    }
    @GetMapping("/{id}") public OrderOut one(Authentication a,@PathVariable Long id){
        boolean admin=a.getAuthorities().stream().anyMatch(x->x.getAuthority().equals("ROLE_ADMIN"));
        return s.one(a.getName(),id,admin);
    }
    @PatchMapping("/{id}/cancel") public OrderOut cancel(Authentication a,@PathVariable Long id){
        return s.cancel(a.getName(),id);
    }
}
