package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.math.*;
@Entity public class OrderItem{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) Order order;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) Product product;
    @Column(nullable=false) Integer quantity;
    @Column(nullable=false,precision=12,scale=2) BigDecimal price,subtotal;
    public Long getId(){
        return id;
    }
    public Order getOrder(){
        return order;
    }
    public void setOrder(Order v){
        order=v;
    }
    public Product getProduct(){
        return product;
    }
    public void setProduct(Product v){
        product=v;
    }
    public Integer getQuantity(){
        return quantity;
    }
    public void setQuantity(Integer v){
        quantity=v;
    }
    public BigDecimal getPrice(){
        return price;
    }
    public void setPrice(BigDecimal v){
        price=v;
    }
    public BigDecimal getSubtotal(){
        return subtotal;
    }
    public void setSubtotal(BigDecimal v){
        subtotal=v;
    }
}
