package com.orbit.ecommerce.exception;
import com.orbit.ecommerce.dto.Dtos;
import jakarta.servlet.http.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import java.time.*;
import java.util.stream.*;
@RestControllerAdvice public class GlobalExceptionHandler{
    @ExceptionHandler(ResourceNotFoundException.class) ResponseEntity<?> n(ResourceNotFoundException e,HttpServletRequest r){
        return b(404,e.getMessage(),r);
    }
    @ExceptionHandler({
        DuplicateResourceException.class,InvalidOrderException.class,InsufficientStockException.class,MethodArgumentNotValidException.class
    }
    ) ResponseEntity<?> b(Exception e,HttpServletRequest r){
        String m=e instanceof MethodArgumentNotValidException v?v.getBindingResult().getFieldErrors().stream().map(x->x.getField()+": "+x.getDefaultMessage()).collect(Collectors.joining("; ")):e.getMessage();
        return b(400,m,r);
    }
    @ExceptionHandler(Exception.class) ResponseEntity<?> x(Exception e,HttpServletRequest r){
        return b(500,"Unexpected server error",r);
    }
    private ResponseEntity<?> b(int s,String m,HttpServletRequest r){
        return ResponseEntity.status(s).body(new ErrorResponse(Instant.now(),s,m,r.getRequestURI()));
    }
    record ErrorResponse(Instant timestamp,int status,String message,String path){
    }
}
