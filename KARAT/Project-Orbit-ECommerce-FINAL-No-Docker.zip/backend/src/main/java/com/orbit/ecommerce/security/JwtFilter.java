package com.orbit.ecommerce.security;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.context.*;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.*;
@Component public class JwtFilter extends OncePerRequestFilter{
    final JwtService jwt;
    final UserDetailsService users;
    public JwtFilter(JwtService j,UserDetailsService u){
        jwt=j;
        users=u;
    }
    protected void doFilterInternal(HttpServletRequest q,HttpServletResponse s,FilterChain c)throws ServletException,IOException{
        String h=q.getHeader("Authorization");
        if(h!=null&&h.startsWith("Bearer "))try{
            String e=jwt.user(h.substring(7));
            UserDetails u=users.loadUserByUsername(e);
            SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(u,null,u.getAuthorities()));
        }
        catch(Exception ignored){
        }
        c.doFilter(q,s);
    }
}
