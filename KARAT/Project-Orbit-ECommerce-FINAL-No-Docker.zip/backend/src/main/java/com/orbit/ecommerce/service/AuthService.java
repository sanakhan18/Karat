package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.*;
import com.orbit.ecommerce.repository.UserRepository;
import com.orbit.ecommerce.security.JwtService;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Service public class AuthService{
    final UserRepository r;
    final PasswordEncoder p;
    final AuthenticationManager am;
    final JwtService jwt;
    public AuthService(UserRepository r,PasswordEncoder p,AuthenticationConfigurationAdapter a,JwtService j){
        this.r=r;
        this.p=p;
        this.am=a.manager();
        this.jwt=j;
    }
    public void register(Register x){
        if(r.existsByEmail(x.email().toLowerCase()))throw new DuplicateResourceException("Email already registered");
        var u=new com.orbit.ecommerce.model.User();
        u.setName(x.name());
        u.setEmail(x.email().toLowerCase());
        u.setPassword(p.encode(x.password()));
        u.setRole(Role.CUSTOMER);
        r.save(u);
    }
    public LoginOut login(Login x){
        String e=x.email().toLowerCase();
        am.authenticate(new UsernamePasswordAuthenticationToken(e,x.password()));
        var u=r.findByEmail(e).orElseThrow();
        var d=User.withUsername(e).password(u.getPassword()).roles(u.getRole().name()).build();
        return new LoginOut(jwt.token(d),"Bearer",u.getId(),u.getName(),u.getEmail(),u.getRole());
    }
    public Me me(String e){
        var u=r.findByEmail(e).orElseThrow();
        return new Me(u.getId(),u.getName(),u.getEmail(),u.getRole());
    }
}
