package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.PaymentReq;
import com.orbit.ecommerce.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/payments") public class PaymentController{
    final PaymentService s;
    public PaymentController(PaymentService s){
        this.s=s;
    }
    @PostMapping public Object create(@Valid @RequestBody PaymentReq x){
        return s.create(x);
    }
    @GetMapping("/{id}") public Object get(@PathVariable Long id){
        return s.get(id);
    }
    @PostMapping("/{id}/refund") public Object refund(@PathVariable Long id){
        return s.refund(id);
    }
}
