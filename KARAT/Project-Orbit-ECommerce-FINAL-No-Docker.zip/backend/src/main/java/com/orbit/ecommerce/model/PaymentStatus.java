package com.orbit.ecommerce.model;
public enum PaymentStatus{
    CREATED,SUCCESS,FAILED,REFUNDED
}
