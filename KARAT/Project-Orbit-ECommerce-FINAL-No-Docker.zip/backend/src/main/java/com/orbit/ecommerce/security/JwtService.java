package com.orbit.ecommerce.security;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.*;
@Service public class JwtService{
    final SecretKey key;
    final long exp;
    public JwtService(@Value("${orbit.jwt.secret}")String s,@Value("${orbit.jwt.expiration-ms}")long e){
        key=Keys.hmacShaKeyFor(s.getBytes(StandardCharsets.UTF_8));
        exp=e;
    }
    public String token(UserDetails u){
        Date n=new Date();
        return Jwts.builder().subject(u.getUsername()).issuedAt(n).expiration(new Date(n.getTime()+exp)).signWith(key).compact();
    }
    public String user(String t){
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(t).getPayload().getSubject();
    }
}
