package com.orbit.ecommerce.repository;
import com.orbit.ecommerce.model.Product;
import org.springframework.data.jpa.repository.*;
import java.util.*;
public interface ProductRepository extends JpaRepository<Product,Long>{
    List<Product> findByActiveTrue();
    List<Product> findByActiveTrueAndCategoryIgnoreCase(String c);
    @Query("select p from Product p where p.active=true and (lower(p.name) like lower(concat('%',:q,'%')) or lower(p.description) like lower(concat('%',:q,'%'))) ") List<Product> search(@Param("q") String q);
}
