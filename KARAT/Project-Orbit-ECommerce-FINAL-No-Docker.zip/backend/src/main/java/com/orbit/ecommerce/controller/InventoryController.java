package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.InventoryReq;
import com.orbit.ecommerce.service.InventoryService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/inventory") public class InventoryController{
    final InventoryService s;
    public InventoryController(InventoryService s){
        this.s=s;
    }
    @GetMapping public Object all(){
        return s.all();
    }
    @GetMapping("/{id}") public Object one(@PathVariable Long id){
        return s.all().stream().filter(p->p.getId().equals(id)).findFirst().orElseThrow();
    }
    @PostMapping public Object post(@RequestParam Long productId,@Valid @RequestBody InventoryReq x){
        return s.set(productId,x);
    }
    @PutMapping("/{id}") public Object set(@PathVariable Long id,@Valid @RequestBody InventoryReq x){
        return s.set(id,x);
    }
    @PatchMapping("/{id}/increase") public Object inc(@PathVariable Long id,@Valid @RequestBody InventoryReq x){
        return s.inc(id,x);
    }
    @PatchMapping("/{id}/decrease") public Object dec(@PathVariable Long id,@Valid @RequestBody InventoryReq x){
        return s.dec(id,x);
    }
}
