package com.orbit.ecommerce;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class OrbitEcommerceApplication{
    public static void main(String[] a){
        SpringApplication.run(OrbitEcommerceApplication.class,a);
    }
}
