package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.InventoryReq;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.*;
@Service public class InventoryService{
    final ProductRepository r;
    public InventoryService(ProductRepository r){
        this.r=r;
    }
    Product p(Long id){
        return r.findById(id).orElseThrow(()->new ResourceNotFoundException("Product not found"));
    }
    public List<Product> all(){
        return r.findAll();
    }
    public Product set(Long id,InventoryReq x){
        var p=p(id);
        p.setStockQuantity(x.quantity());
        return r.save(p);
    }
    public Product inc(Long id,InventoryReq x){
        var p=p(id);
        p.setStockQuantity(p.getStockQuantity()+x.quantity());
        return r.save(p);
    }
    public Product dec(Long id,InventoryReq x){
        var p=p(id);
        if(p.getStockQuantity()<x.quantity())throw new InsufficientStockException("Cannot decrease below zero");
        p.setStockQuantity(p.getStockQuantity()-x.quantity());
        return r.save(p);
    }
}
