package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.*;
import com.orbit.ecommerce.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.*;
import java.util.*;
@Service public class OrderService{
    final OrderRepository r;
    final ProductRepository p;
    final UserRepository u;
    public OrderService(OrderRepository r,ProductRepository p,UserRepository u){
        this.r=r;
        this.p=p;
        this.u=u;
    }
    Order get(Long id){
        return r.findById(id).orElseThrow(()->new ResourceNotFoundException("Order "+id+" not found"));
    }
    OrderOut out(Order o){
        var is=o.getItems().stream().map(i->new ItemOut(i.getId(),i.getProduct().getId(),i.getProduct().getName(),i.getQuantity(),i.getPrice(),i.getSubtotal())).toList();
        return new OrderOut(o.getId(),o.getOrderNumber(),o.getUser().getId(),o.getUser().getName(),o.getTotalAmount(),o.getStatus(),o.getCreatedAt(),o.getUpdatedAt(),is);
    }
    @Transactional public OrderOut create(String email,OrderReq req){
        var user=u.findByEmail(email).orElseThrow();
        var o=new Order();
        o.setUser(user);
        o.setOrderNumber("ORB-"+System.currentTimeMillis());
        BigDecimal total=BigDecimal.ZERO;
        for(var x:req.items()){
            var pr=p.findById(x.productId()).orElseThrow(()->new ResourceNotFoundException("Product not found"));
            if(!pr.isActive())throw new InvalidOrderException("Inactive product");
            if(pr.getStockQuantity()<x.quantity())throw new InsufficientStockException("Insufficient stock for "+pr.getName());
            var sub=pr.getPrice().multiply(BigDecimal.valueOf(x.quantity()));
            var i=new OrderItem();
            i.setProduct(pr);
            i.setQuantity(x.quantity());
            i.setPrice(pr.getPrice());
            i.setSubtotal(sub);
            o.add(i);
            pr.setStockQuantity(pr.getStockQuantity()-x.quantity());
            total=total.add(sub);
        }
        o.setTotalAmount(total);
        return out(r.save(o));
    }
    public List<OrderOut> mine(String e){
        var u1=u.findByEmail(e).orElseThrow();
        return r.findByUserIdOrderByCreatedAtDesc(u1.getId()).stream().map(this::out).toList();
    }
    public OrderOut one(String e,Long id,boolean admin){
        var o=get(id);
        if(!admin&&!o.getUser().getEmail().equals(e))throw new UnauthorizedException("You cannot access this order");
        return out(o);
    }
    @Transactional public OrderOut cancel(String e,Long id){
        var o=get(id);
        if(!o.getUser().getEmail().equals(e))throw new UnauthorizedException("Not your order");
        if(o.getStatus()!=OrderStatus.CREATED&&o.getStatus()!=OrderStatus.CONFIRMED)throw new InvalidOrderException("Order cannot be cancelled now");
        o.getItems().forEach(i->i.getProduct().setStockQuantity(i.getProduct().getStockQuantity()+i.getQuantity()));
        o.setStatus(OrderStatus.CANCELLED);
        return out(o);
    }
    @Transactional public OrderOut status(Long id,OrderStatus s){
        var o=get(id);
        boolean ok=switch(o.getStatus()){
            case CREATED->s==OrderStatus.CONFIRMED||s==OrderStatus.CANCELLED;
            case CONFIRMED->s==OrderStatus.PROCESSING||s==OrderStatus.CANCELLED;
            case PROCESSING->s==OrderStatus.SHIPPED;
            case SHIPPED->s==OrderStatus.DELIVERED;
            default->false;
        }
        ;
        if(!ok)throw new InvalidOrderException("Invalid status transition");
        o.setStatus(s);
        return out(o);
    }
    public List<OrderOut> all(){
        return r.findAllByOrderByCreatedAtDesc().stream().map(this::out).toList();
    }
    public List<OrderOut> by(OrderStatus s){
        return r.findByStatusOrderByCreatedAtDesc(s).stream().map(this::out).toList();
    }
    public Order entity(Long id){
        return get(id);
    }
}
