package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.*;
@Service public class ProductService{
    final ProductRepository r;
    public ProductService(ProductRepository r){
        this.r=r;
    }
    Product get(Long id){
        return r.findById(id).orElseThrow(()->new ResourceNotFoundException("Product "+id+" not found"));
    }
    ProductOut o(Product p){
        return new ProductOut(p.getId(),p.getName(),p.getDescription(),p.getPrice(),p.getCategory(),p.getStockQuantity(),p.getImageUrl(),p.isActive(),p.getCreatedAt(),p.getUpdatedAt());
    }
    public List<ProductOut> all(){
        return r.findByActiveTrue().stream().map(this::o).toList();
    }
    public ProductOut one(Long id){
        var p=get(id);
        if(!p.isActive())throw new ResourceNotFoundException("Product not found");
        return o(p);
    }
    public List<ProductOut> search(String q){
        return r.search(q).stream().map(this::o).toList();
    }
    public List<ProductOut> cat(String c){
        return r.findByActiveTrueAndCategoryIgnoreCase(c).stream().map(this::o).toList();
    }
    void apply(Product p,ProductReq x){
        p.setName(x.name());
        p.setDescription(x.description());
        p.setPrice(x.price());
        p.setCategory(x.category());
        p.setStockQuantity(x.stockQuantity());
        p.setImageUrl(x.imageUrl());
        if(x.active()!=null)p.setActive(x.active());
    }
    public ProductOut create(ProductReq x){
        var p=new Product();
        apply(p,x);
        return o(r.save(p));
    }
    public ProductOut update(Long id,ProductReq x){
        var p=get(id);
        apply(p,x);
        return o(r.save(p));
    }
    public void delete(Long id){
        r.delete(get(id));
    }
    public ProductOut active(Long id,boolean v){
        var p=get(id);
        p.setActive(v);
        return o(r.save(p));
    }
    public Product entity(Long id){
        return get(id);
    }
}
