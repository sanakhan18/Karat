package com.orbit.ecommerce.repository;
import com.orbit.ecommerce.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface PaymentRepository extends JpaRepository<Payment,Long>{
    Optional<Payment> findByOrderId(Long id);
}
