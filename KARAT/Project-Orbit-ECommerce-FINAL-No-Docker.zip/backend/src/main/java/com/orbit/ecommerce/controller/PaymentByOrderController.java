package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/orders") public class PaymentByOrderController{
    final PaymentService s;
    public PaymentByOrderController(PaymentService s){
        this.s=s;
    }
    @GetMapping("/{id}/payment") public Object get(@PathVariable Long id){
        return s.byOrder(id);
    }
}
