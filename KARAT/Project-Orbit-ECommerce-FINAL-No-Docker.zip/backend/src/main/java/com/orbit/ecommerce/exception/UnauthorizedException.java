package com.orbit.ecommerce.exception;
public class UnauthorizedException extends RuntimeException{
    public UnauthorizedException(String m){
        super(m);
    }
}
