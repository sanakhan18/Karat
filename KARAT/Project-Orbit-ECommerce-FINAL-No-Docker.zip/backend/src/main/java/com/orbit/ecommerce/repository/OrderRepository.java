package com.orbit.ecommerce.repository;
import com.orbit.ecommerce.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface OrderRepository extends JpaRepository<Order,Long>{
    List<Order> findByUserIdOrderByCreatedAtDesc(Long id);
    List<Order> findAllByOrderByCreatedAtDesc();
    List<Order> findByStatusOrderByCreatedAtDesc(OrderStatus s);
}
