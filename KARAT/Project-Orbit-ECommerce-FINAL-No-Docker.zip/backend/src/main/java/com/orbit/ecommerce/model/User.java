package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.time.*;
@Entity @Table(name="users",uniqueConstraints=@UniqueConstraint(columnNames="email")) public class User{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    @Column(nullable=false) String name;
    @Column(nullable=false,unique=true) String email;
    @Column(nullable=false) String password;
    @Enumerated(EnumType.STRING) @Column(nullable=false) Role role=Role.CUSTOMER;
    LocalDateTime createdAt,updatedAt;
    @PrePersist void c(){
        createdAt=updatedAt=LocalDateTime.now();
    }
    @PreUpdate void u(){
        updatedAt=LocalDateTime.now();
    }
    public Long getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public void setName(String v){
        name=v;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String v){
        email=v;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String v){
        password=v;
    }
    public Role getRole(){
        return role;
    }
    public void setRole(Role v){
        role=v;
    }
}
