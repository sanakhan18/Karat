package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.math.*;
import java.time.*;
@Entity public class Product{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    @Column(nullable=false) String name;
    String description;
    @Column(nullable=false,precision=12,scale=2) BigDecimal price;
    @Column(nullable=false) String category;
    @Column(nullable=false) Integer stockQuantity;
    String imageUrl;
    boolean active=true;
    LocalDateTime createdAt,updatedAt;
    @PrePersist void c(){
        createdAt=updatedAt=LocalDateTime.now();
    }
    @PreUpdate void u(){
        updatedAt=LocalDateTime.now();
    }
    public Long getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public void setName(String v){
        name=v;
    }
    public String getDescription(){
        return description;
    }
    public void setDescription(String v){
        description=v;
    }
    public BigDecimal getPrice(){
        return price;
    }
    public void setPrice(BigDecimal v){
        price=v;
    }
    public String getCategory(){
        return category;
    }
    public void setCategory(String v){
        category=v;
    }
    public Integer getStockQuantity(){
        return stockQuantity;
    }
    public void setStockQuantity(Integer v){
        stockQuantity=v;
    }
    public String getImageUrl(){
        return imageUrl;
    }
    public void setImageUrl(String v){
        imageUrl=v;
    }
    public boolean isActive(){
        return active;
    }
    public void setActive(boolean v){
        active=v;
    }
    public LocalDateTime getCreatedAt(){
        return createdAt;
    }
    public LocalDateTime getUpdatedAt(){
        return updatedAt;
    }
}
