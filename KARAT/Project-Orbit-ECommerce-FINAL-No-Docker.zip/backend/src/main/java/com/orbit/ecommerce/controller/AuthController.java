package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.*;
import com.orbit.ecommerce.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/auth") public class AuthController{
    final AuthService s;
    public AuthController(AuthService s){
        this.s=s;
    }
    @PostMapping("/register") public String reg(@Valid @RequestBody Register x){
        s.register(x);
        return "Registration successful";
    }
    @PostMapping("/login") public LoginOut login(@Valid @RequestBody Login x){
        return s.login(x);
    }
    @GetMapping("/me") public Me me(Authentication a){
        return s.me(a.getName());
    }
}
