package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.math.*;
import java.time.*;
@Entity public class Payment{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    @OneToOne(optional=false) @JoinColumn(name="order_id",unique=true) Order order;
    @Column(nullable=false,precision=12,scale=2) BigDecimal amount;
    @Enumerated(EnumType.STRING) PaymentStatus status=PaymentStatus.CREATED;
    String method;
    LocalDateTime createdAt;
    @PrePersist void c(){
        createdAt=LocalDateTime.now();
    }
    public Long getId(){
        return id;
    }
    public Order getOrder(){
        return order;
    }
    public void setOrder(Order v){
        order=v;
    }
    public BigDecimal getAmount(){
        return amount;
    }
    public void setAmount(BigDecimal v){
        amount=v;
    }
    public PaymentStatus getStatus(){
        return status;
    }
    public void setStatus(PaymentStatus v){
        status=v;
    }
    public String getMethod(){
        return method;
    }
    public void setMethod(String v){
        method=v;
    }
    public LocalDateTime getCreatedAt(){
        return createdAt;
    }
}
