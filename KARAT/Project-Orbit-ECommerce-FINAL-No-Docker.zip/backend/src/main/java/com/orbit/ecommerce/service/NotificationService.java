package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.NotificationReq;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.Notification;
import com.orbit.ecommerce.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import java.util.*;
@Service public class NotificationService{
    final NotificationRepository r;
    public NotificationService(NotificationRepository r){
        this.r=r;
    }
    public Notification create(NotificationReq x){
        var n=new Notification();
        n.setUserId(x.userId());
        n.setMessage(x.message());
        return r.save(n);
    }
    public Notification get(Long id){
        return r.findById(id).orElseThrow(()->new ResourceNotFoundException("Notification not found"));
    }
    public List<Notification> user(Long id){
        return r.findByUserIdOrderByCreatedAtDesc(id);
    }
}
