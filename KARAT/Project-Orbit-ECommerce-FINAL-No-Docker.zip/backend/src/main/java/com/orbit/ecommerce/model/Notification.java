package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.time.*;
@Entity public class Notification{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    Long userId;
    String message;
    boolean readFlag;
    LocalDateTime createdAt;
    @PrePersist void c(){
        createdAt=LocalDateTime.now();
    }
    public Long getId(){
        return id;
    }
    public Long getUserId(){
        return userId;
    }
    public void setUserId(Long v){
        userId=v;
    }
    public String getMessage(){
        return message;
    }
    public void setMessage(String v){
        message=v;
    }
    public boolean isReadFlag(){
        return readFlag;
    }
    public LocalDateTime getCreatedAt(){
        return createdAt;
    }
}
