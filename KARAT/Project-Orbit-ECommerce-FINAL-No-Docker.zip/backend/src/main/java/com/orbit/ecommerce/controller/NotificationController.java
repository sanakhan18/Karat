package com.orbit.ecommerce.controller;
import com.orbit.ecommerce.dto.Dtos.NotificationReq;
import com.orbit.ecommerce.service.NotificationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/notifications") public class NotificationController{
    final NotificationService s;
    public NotificationController(NotificationService s){
        this.s=s;
    }
    @PostMapping public Object create(@Valid @RequestBody NotificationReq x){
        return s.create(x);
    }
    @GetMapping("/{id}") public Object get(@PathVariable Long id){
        return s.get(id);
    }
    @GetMapping("/user/{id}") public Object user(@PathVariable Long id){
        return s.user(id);
    }
}
