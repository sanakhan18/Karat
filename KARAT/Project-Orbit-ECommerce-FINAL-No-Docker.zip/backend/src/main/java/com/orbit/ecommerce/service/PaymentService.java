package com.orbit.ecommerce.service;
import com.orbit.ecommerce.dto.Dtos.PaymentReq;
import com.orbit.ecommerce.exception.*;
import com.orbit.ecommerce.model.*;
import com.orbit.ecommerce.repository.*;
import org.springframework.stereotype.Service;
@Service public class PaymentService{
    final PaymentRepository r;
    final OrderRepository o;
    public PaymentService(PaymentRepository r,OrderRepository o){
        this.r=r;
        this.o=o;
    }
    public Payment create(PaymentReq x){
        var order=o.findById(x.orderId()).orElseThrow(()->new ResourceNotFoundException("Order not found"));
        if(r.findByOrderId(order.getId()).isPresent())throw new DuplicateResourceException("Payment already exists");
        var p=new Payment();
        p.setOrder(order);
        p.setAmount(order.getTotalAmount());
        p.setMethod(x.method());
        p.setStatus(PaymentStatus.SUCCESS);
        return r.save(p);
    }
    public Payment get(Long id){
        return r.findById(id).orElseThrow(()->new ResourceNotFoundException("Payment not found"));
    }
    public Payment byOrder(Long id){
        return r.findByOrderId(id).orElseThrow(()->new ResourceNotFoundException("Payment not found"));
    }
    public Payment refund(Long id){
        var p=get(id);
        if(p.getStatus()!=PaymentStatus.SUCCESS)throw new InvalidOrderException("Only successful payment can be refunded");
        p.setStatus(PaymentStatus.REFUNDED);
        return r.save(p);
    }
}
