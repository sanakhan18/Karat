package com.orbit.ecommerce.service;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.stereotype.Component;
@Component public class AuthenticationConfigurationAdapter{
    final AuthenticationConfiguration c;
    public AuthenticationConfigurationAdapter(AuthenticationConfiguration c){
        this.c=c;
    }
    public AuthenticationManager manager(){
        try{
            return c.getAuthenticationManager();
        }
        catch(Exception e){
            throw new IllegalStateException(e);
        }
    }
}
