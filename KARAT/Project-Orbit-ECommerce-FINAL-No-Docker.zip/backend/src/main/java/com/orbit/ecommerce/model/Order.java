package com.orbit.ecommerce.model;
import jakarta.persistence.*;
import java.math.*;
import java.time.*;
import java.util.*;
@Entity @Table(name="orders") public class Order{
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) Long id;
    @Column(nullable=false,unique=true) String orderNumber;
    @ManyToOne(fetch=FetchType.LAZY,optional=false) User user;
    @Column(nullable=false,precision=12,scale=2) BigDecimal totalAmount=BigDecimal.ZERO;
    @Enumerated(EnumType.STRING) OrderStatus status=OrderStatus.CREATED;
    LocalDateTime createdAt,updatedAt;
    @OneToMany(mappedBy="order",cascade=CascadeType.ALL,orphanRemoval=true) List<OrderItem> items=new ArrayList<>();
    @PrePersist void c(){
        createdAt=updatedAt=LocalDateTime.now();
    }
    @PreUpdate void u(){
        updatedAt=LocalDateTime.now();
    }
    public void add(OrderItem i){
        items.add(i);
        i.setOrder(this);
    }
    public Long getId(){
        return id;
    }
    public String getOrderNumber(){
        return orderNumber;
    }
    public void setOrderNumber(String v){
        orderNumber=v;
    }
    public User getUser(){
        return user;
    }
    public void setUser(User v){
        user=v;
    }
    public BigDecimal getTotalAmount(){
        return totalAmount;
    }
    public void setTotalAmount(BigDecimal v){
        totalAmount=v;
    }
    public OrderStatus getStatus(){
        return status;
    }
    public void setStatus(OrderStatus v){
        status=v;
    }
    public LocalDateTime getCreatedAt(){
        return createdAt;
    }
    public LocalDateTime getUpdatedAt(){
        return updatedAt;
    }
    public List<OrderItem> getItems(){
        return items;
    }
}
