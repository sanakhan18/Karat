package com.orbit.ecommerce.config;

import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.model.Role;
import com.orbit.ecommerce.model.User;
import com.orbit.ecommerce.repository.ProductRepository;
import com.orbit.ecommerce.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seed(UserRepository users, ProductRepository products, PasswordEncoder encoder) {
        return args -> {
            if (!users.existsByEmail("admin@orbit.com")) {
                User admin = new User();
                admin.setName("Orbit Admin");
                admin.setEmail("admin@orbit.com");
                admin.setPassword(encoder.encode("Admin@123"));
                admin.setRole(Role.ADMIN);
                users.save(admin);
            }

            if (products.count() == 0) {
                products.save(product("Laptop Pro 14", "Training laptop", "Electronics", "79999", 10));
                products.save(product("Wireless Headphones", "Noise cancelling headphones", "Electronics", "4999", 25));
                products.save(product("Office Chair", "Ergonomic chair", "Furniture", "8999", 8));
                products.save(product("Running Shoes", "Lightweight shoes", "Fashion", "3499", 20));
            }
        };
    }

    private Product product(String name, String description, String category, String price, int stock) {
        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setCategory(category);
        product.setPrice(new BigDecimal(price));
        product.setStockQuantity(stock);
        product.setImageUrl("https://images.unsplash.com/photo-1496181133206-80ce9b88a853");
        return product;
    }
}
