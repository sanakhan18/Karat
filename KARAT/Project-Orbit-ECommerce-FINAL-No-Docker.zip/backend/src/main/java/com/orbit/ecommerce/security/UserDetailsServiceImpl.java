package com.orbit.ecommerce.security;
import com.orbit.ecommerce.repository.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
@Service public class UserDetailsServiceImpl implements UserDetailsService{
    final UserRepository r;
    public UserDetailsServiceImpl(UserRepository r){
        this.r=r;
    }
    public UserDetails loadUserByUsername(String e){
        var u=r.findByEmail(e).orElseThrow(()->new UsernameNotFoundException("User not found"));
        return User.withUsername(u.getEmail()).password(u.getPassword()).roles(u.getRole().name()).build();
    }
}
