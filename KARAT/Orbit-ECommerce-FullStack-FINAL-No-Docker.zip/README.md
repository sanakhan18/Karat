# Project Orbit E-Commerce Portal - Final No Docker

Full-stack Project Orbit implementation based on the supplied specification: Spring Boot REST backend, JWT authentication, H2 database for a zero-install local demo, API Gateway, and React/Vite frontend.

## Run components

1. Backend: `backend/src/main/java/com/orbit/ecommerce/OrbitEcommerceApplication.java` -> Run Java -> port 8081.
2. API Gateway: `api-gateway/src/main/java/com/orbit/gateway/ApiGatewayApplication.java` -> Run Java -> port 8080.
3. Frontend: terminal in `frontend` -> `npm install` -> `npm run dev` -> port 5173.

Docker and PostgreSQL are intentionally not required.

## Gateway

The React application calls `http://localhost:8080`.
The gateway forwards `/api/**` to `http://localhost:8081`.

## Demo accounts

Admin: `admin@orbit.com` / `Admin@123`
Customer: `customer@orbit.com` / `Customer@123`

## Main flow

Register/login -> browse products -> add to cart -> create order -> stock decreases -> create payment -> view orders -> admin changes order status.

## Postman

Import `postman/Project-Orbit-Gateway.postman_collection.json`.
