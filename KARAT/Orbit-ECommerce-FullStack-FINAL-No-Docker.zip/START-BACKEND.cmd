@echo off
cd /d "%~dp0backend"
echo Open OrbitEcommerceApplication.java in VS Code and use Run Java.
pause
