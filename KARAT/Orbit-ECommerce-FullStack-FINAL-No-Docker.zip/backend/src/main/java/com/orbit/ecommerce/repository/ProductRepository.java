package com.orbit.ecommerce.repository;

import com.orbit.ecommerce.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByActiveTrue();
    List<Product> findByActiveTrueAndCategoryIgnoreCase(String category);

    @Query("select p from Product p where p.active = true and " +
           "(lower(p.name) like lower(concat('%', :query, '%')) or " +
           "lower(coalesce(p.description, '')) like lower(concat('%', :query, '%')))" )
    List<Product> search(@Param("query") String query);
}
