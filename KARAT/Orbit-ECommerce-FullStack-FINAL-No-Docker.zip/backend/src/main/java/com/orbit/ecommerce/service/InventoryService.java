package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.InventoryDtos.InventoryRequest;
import com.orbit.ecommerce.dto.InventoryDtos.InventoryResponse;
import com.orbit.ecommerce.exception.InsufficientStockException;
import com.orbit.ecommerce.model.Product;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class InventoryService {

    private final ProductService productService;

    public InventoryService(ProductService productService) {
        this.productService = productService;
    }

    public List<InventoryResponse> findAll() {
        return productService.findAll().stream()
            .map(product -> new InventoryResponse(
                product.id(),
                product.name(),
                product.stockQuantity(),
                product.price()
            ))
            .toList();
    }

    public InventoryResponse findByProductId(Long productId) {
        return toResponse(productService.findEntity(productId));
    }

    @Transactional
    public InventoryResponse set(Long productId, InventoryRequest request) {
        Product product = productService.findEntity(productId);
        product.setStockQuantity(request.quantity());
        return toResponse(product);
    }

    @Transactional
    public InventoryResponse increase(Long productId, InventoryRequest request) {
        Product product = productService.findEntity(productId);
        product.setStockQuantity(product.getStockQuantity() + request.quantity());
        return toResponse(product);
    }

    @Transactional
    public InventoryResponse decrease(Long productId, InventoryRequest request) {
        Product product = productService.findEntity(productId);
        if (product.getStockQuantity() < request.quantity()) {
            throw new InsufficientStockException("Cannot decrease stock below zero");
        }
        product.setStockQuantity(product.getStockQuantity() - request.quantity());
        return toResponse(product);
    }

    private InventoryResponse toResponse(Product product) {
        return new InventoryResponse(
            product.getId(),
            product.getName(),
            product.getStockQuantity(),
            product.getPrice()
        );
    }
}
