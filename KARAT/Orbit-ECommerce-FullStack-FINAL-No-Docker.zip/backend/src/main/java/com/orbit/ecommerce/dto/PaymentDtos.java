package com.orbit.ecommerce.dto;

import com.orbit.ecommerce.model.PaymentStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public final class PaymentDtos {

    private PaymentDtos() {
    }

    public record PaymentRequest(
        @NotNull Long orderId,
        @NotBlank String method
    ) {
    }

    public record PaymentResponse(
        Long id,
        Long orderId,
        BigDecimal amount,
        PaymentStatus status,
        String method,
        LocalDateTime createdAt
    ) {
    }
}
