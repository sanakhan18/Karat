package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.PaymentDtos.PaymentRequest;
import com.orbit.ecommerce.dto.PaymentDtos.PaymentResponse;
import com.orbit.ecommerce.exception.DuplicateResourceException;
import com.orbit.ecommerce.exception.InvalidOrderException;
import com.orbit.ecommerce.exception.ResourceNotFoundException;
import com.orbit.ecommerce.model.Order;
import com.orbit.ecommerce.model.Payment;
import com.orbit.ecommerce.model.PaymentStatus;
import com.orbit.ecommerce.repository.OrderRepository;
import com.orbit.ecommerce.repository.PaymentRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;

    public PaymentService(
        PaymentRepository paymentRepository,
        OrderRepository orderRepository
    ) {
        this.paymentRepository = paymentRepository;
        this.orderRepository = orderRepository;
    }

    public PaymentResponse create(PaymentRequest request) {
        Order order = findOrder(request.orderId());
        if (paymentRepository.findByOrderId(order.getId()).isPresent()) {
            throw new DuplicateResourceException("Payment already exists for this order");
        }

        Payment payment = new Payment();
        payment.setOrder(order);
        payment.setAmount(order.getTotalAmount());
        payment.setMethod(request.method().trim());
        payment.setStatus(PaymentStatus.SUCCESS);
        return toResponse(paymentRepository.save(payment));
    }

    public PaymentResponse findById(Long id) {
        return toResponse(paymentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Payment not found")));
    }

    public PaymentResponse findByOrderId(Long orderId) {
        return toResponse(paymentRepository.findByOrderId(orderId)
            .orElseThrow(() -> new ResourceNotFoundException("Payment not found")));
    }

    public PaymentResponse refund(Long id) {
        Payment payment = paymentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));
        if (payment.getStatus() != PaymentStatus.SUCCESS) {
            throw new InvalidOrderException("Only successful payments can be refunded");
        }
        payment.setStatus(PaymentStatus.REFUNDED);
        return toResponse(paymentRepository.save(payment));
    }

    private Order findOrder(Long id) {
        return orderRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Order not found"));
    }

    private PaymentResponse toResponse(Payment payment) {
        return new PaymentResponse(
            payment.getId(),
            payment.getOrder().getId(),
            payment.getAmount(),
            payment.getStatus(),
            payment.getMethod(),
            payment.getCreatedAt()
        );
    }
}
