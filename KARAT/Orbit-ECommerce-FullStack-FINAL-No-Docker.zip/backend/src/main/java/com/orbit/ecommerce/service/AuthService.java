package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.AuthDtos.LoginRequest;
import com.orbit.ecommerce.dto.AuthDtos.LoginResponse;
import com.orbit.ecommerce.dto.AuthDtos.MeResponse;
import com.orbit.ecommerce.dto.AuthDtos.RegisterRequest;
import com.orbit.ecommerce.exception.DuplicateResourceException;
import com.orbit.ecommerce.model.Role;
import com.orbit.ecommerce.model.User;
import com.orbit.ecommerce.repository.UserRepository;
import com.orbit.ecommerce.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthService(
        UserRepository userRepository,
        PasswordEncoder passwordEncoder,
        AuthenticationManager authenticationManager,
        JwtService jwtService
    ) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    public void register(RegisterRequest request) {
        String email = normalize(request.email());
        if (userRepository.existsByEmail(email)) {
            throw new DuplicateResourceException("Email already registered");
        }

        User user = new User();
        user.setName(request.name().trim());
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole(Role.CUSTOMER);
        userRepository.save(user);
    }

    public LoginResponse login(LoginRequest request) {
        String email = normalize(request.email());
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(email, request.password())
        );

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new IllegalArgumentException("User not found"));

        UserDetails details = org.springframework.security.core.userdetails.User
            .withUsername(user.getEmail())
            .password(user.getPassword())
            .roles(user.getRole().name())
            .build();

        return new LoginResponse(
            jwtService.generateToken(details),
            "Bearer",
            user.getId(),
            user.getName(),
            user.getEmail(),
            user.getRole()
        );
    }

    public MeResponse me(String email) {
        User user = findUser(email);
        return new MeResponse(user.getId(), user.getName(), user.getEmail(), user.getRole());
    }

    public User findUser(String email) {
        return userRepository.findByEmail(normalize(email))
            .orElseThrow(() -> new IllegalArgumentException("User not found"));
    }

    private String normalize(String email) {
        return email.trim().toLowerCase();
    }
}
