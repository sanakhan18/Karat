package com.orbit.ecommerce.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public final class InventoryDtos {

    private InventoryDtos() {
    }

    public record InventoryRequest(@NotNull @Min(0) Integer quantity) {
    }

    public record InventoryResponse(
        Long productId,
        String productName,
        Integer stockQuantity,
        BigDecimal price
    ) {
    }
}
