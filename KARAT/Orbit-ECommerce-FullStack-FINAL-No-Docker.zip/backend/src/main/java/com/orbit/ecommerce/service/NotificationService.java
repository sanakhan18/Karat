package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.NotificationDtos.NotificationRequest;
import com.orbit.ecommerce.exception.ResourceNotFoundException;
import com.orbit.ecommerce.model.Notification;
import com.orbit.ecommerce.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public Notification create(NotificationRequest request) {
        Notification notification = new Notification();
        notification.setUserId(request.userId());
        notification.setMessage(request.message());
        return notificationRepository.save(notification);
    }

    public Notification findById(Long id) {
        return notificationRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
    }

    public List<Notification> findByUser(Long userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }
}
