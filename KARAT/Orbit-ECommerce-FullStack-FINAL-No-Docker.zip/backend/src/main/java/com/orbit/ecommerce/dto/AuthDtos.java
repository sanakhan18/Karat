package com.orbit.ecommerce.dto;

import com.orbit.ecommerce.model.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public final class AuthDtos {

    private AuthDtos() {
    }

    public record RegisterRequest(
        @NotBlank String name,
        @Email @NotBlank String email,
        @Size(min = 8) String password
    ) {
    }

    public record LoginRequest(
        @Email @NotBlank String email,
        @NotBlank String password
    ) {
    }

    public record LoginResponse(
        String token,
        String tokenType,
        Long userId,
        String name,
        String email,
        Role role
    ) {
    }

    public record MeResponse(
        Long id,
        String name,
        String email,
        Role role
    ) {
    }
}
