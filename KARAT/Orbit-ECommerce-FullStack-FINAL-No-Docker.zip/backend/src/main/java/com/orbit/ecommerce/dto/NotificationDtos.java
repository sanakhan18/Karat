package com.orbit.ecommerce.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public final class NotificationDtos {

    private NotificationDtos() {
    }

    public record NotificationRequest(
        @NotNull Long userId,
        @NotBlank String message
    ) {
    }
}
