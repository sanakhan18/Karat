package com.orbit.ecommerce.controller;

import com.orbit.ecommerce.dto.InventoryDtos.InventoryRequest;
import com.orbit.ecommerce.dto.InventoryDtos.InventoryResponse;
import com.orbit.ecommerce.service.InventoryService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    private final InventoryService inventoryService;

    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    @GetMapping
    public List<InventoryResponse> findAll() {
        return inventoryService.findAll();
    }

    @GetMapping("/{productId}")
    public InventoryResponse findByProductId(@PathVariable Long productId) {
        return inventoryService.findByProductId(productId);
    }

    @PostMapping
    public InventoryResponse createOrSet(
        @RequestParam Long productId,
        @Valid @RequestBody InventoryRequest request
    ) {
        return inventoryService.set(productId, request);
    }

    @PutMapping("/{productId}")
    public InventoryResponse set(
        @PathVariable Long productId,
        @Valid @RequestBody InventoryRequest request
    ) {
        return inventoryService.set(productId, request);
    }

    @PatchMapping("/{productId}/increase")
    public InventoryResponse increase(
        @PathVariable Long productId,
        @Valid @RequestBody InventoryRequest request
    ) {
        return inventoryService.increase(productId, request);
    }

    @PatchMapping("/{productId}/decrease")
    public InventoryResponse decrease(
        @PathVariable Long productId,
        @Valid @RequestBody InventoryRequest request
    ) {
        return inventoryService.decrease(productId, request);
    }
}
