package com.orbit.ecommerce.controller;

import com.orbit.ecommerce.dto.PaymentDtos.PaymentResponse;
import com.orbit.ecommerce.service.PaymentService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/orders")
public class PaymentByOrderController {

    private final PaymentService paymentService;

    public PaymentByOrderController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/{orderId}/payment")
    public PaymentResponse findByOrderId(@PathVariable Long orderId) {
        return paymentService.findByOrderId(orderId);
    }
}
