package com.orbit.ecommerce.dto;

import com.orbit.ecommerce.model.OrderStatus;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public final class OrderDtos {

    private OrderDtos() {
    }

    public record OrderItemRequest(
        @NotNull Long productId,
        @NotNull @Min(1) Integer quantity
    ) {
    }

    public record OrderRequest(
        @NotEmpty List<@Valid OrderItemRequest> items
    ) {
    }

    public record OrderItemResponse(
        Long id,
        Long productId,
        String productName,
        Integer quantity,
        BigDecimal price,
        BigDecimal subtotal
    ) {
    }

    public record OrderResponse(
        Long id,
        String orderNumber,
        Long userId,
        String userName,
        BigDecimal totalAmount,
        OrderStatus status,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        List<OrderItemResponse> items
    ) {
    }

    public record StatusRequest(@NotNull OrderStatus status) {
    }
}
