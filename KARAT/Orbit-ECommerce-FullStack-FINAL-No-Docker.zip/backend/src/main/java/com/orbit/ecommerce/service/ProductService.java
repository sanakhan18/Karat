package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.ProductDtos.ProductRequest;
import com.orbit.ecommerce.dto.ProductDtos.ProductResponse;
import com.orbit.ecommerce.exception.ResourceNotFoundException;
import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<ProductResponse> findAll() {
        return productRepository.findByActiveTrue().stream().map(this::toResponse).toList();
    }

    public ProductResponse findById(Long id) {
        Product product = findEntity(id);
        if (!product.isActive()) {
            throw new ResourceNotFoundException("Product not found");
        }
        return toResponse(product);
    }

    public List<ProductResponse> search(String query) {
        return productRepository.search(query == null ? "" : query.trim())
            .stream()
            .map(this::toResponse)
            .toList();
    }

    public List<ProductResponse> findByCategory(String category) {
        return productRepository.findByActiveTrueAndCategoryIgnoreCase(category)
            .stream()
            .map(this::toResponse)
            .toList();
    }

    public ProductResponse create(ProductRequest request) {
        Product product = new Product();
        apply(product, request);
        return toResponse(productRepository.save(product));
    }

    public ProductResponse update(Long id, ProductRequest request) {
        Product product = findEntity(id);
        apply(product, request);
        return toResponse(productRepository.save(product));
    }

    public void delete(Long id) {
        productRepository.delete(findEntity(id));
    }

    public ProductResponse setActive(Long id, boolean active) {
        Product product = findEntity(id);
        product.setActive(active);
        return toResponse(productRepository.save(product));
    }

    public Product findEntity(Long id) {
        return productRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Product " + id + " not found"));
    }

    private void apply(Product product, ProductRequest request) {
        product.setName(request.name().trim());
        product.setDescription(request.description());
        product.setPrice(request.price());
        product.setCategory(request.category().trim());
        product.setStockQuantity(request.stockQuantity());
        product.setImageUrl(request.imageUrl());
        if (request.active() != null) {
            product.setActive(request.active());
        }
    }

    private ProductResponse toResponse(Product product) {
        return new ProductResponse(
            product.getId(),
            product.getName(),
            product.getDescription(),
            product.getPrice(),
            product.getCategory(),
            product.getStockQuantity(),
            product.getImageUrl(),
            product.isActive(),
            product.getCreatedAt(),
            product.getUpdatedAt()
        );
    }
}
