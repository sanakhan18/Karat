package com.orbit.ecommerce.config;

import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.model.Role;
import com.orbit.ecommerce.model.User;
import com.orbit.ecommerce.repository.ProductRepository;
import com.orbit.ecommerce.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seedData(
        UserRepository userRepository,
        ProductRepository productRepository,
        PasswordEncoder passwordEncoder
    ) {
        return args -> {
            seedUsers(userRepository, passwordEncoder);
            seedProducts(productRepository);
        };
    }

    private void seedUsers(UserRepository repository, PasswordEncoder encoder) {
        if (!repository.existsByEmail("admin@orbit.com")) {
            repository.save(createUser("Orbit Admin", "admin@orbit.com", "Admin@123", Role.ADMIN, encoder));
        }
        if (!repository.existsByEmail("customer@orbit.com")) {
            repository.save(createUser("Orbit Customer", "customer@orbit.com", "Customer@123", Role.CUSTOMER, encoder));
        }
    }

    private User createUser(
        String name,
        String email,
        String password,
        Role role,
        PasswordEncoder encoder
    ) {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(encoder.encode(password));
        user.setRole(role);
        return user;
    }

    private void seedProducts(ProductRepository repository) {
        if (repository.count() > 0) {
            return;
        }
        repository.save(product("Laptop Pro 14", "Professional laptop", "Electronics", "79999.00", 10));
        repository.save(product("Wireless Headphones", "Noise cancelling headphones", "Electronics", "4999.00", 20));
        repository.save(product("Mechanical Keyboard", "RGB mechanical keyboard", "Accessories", "3499.00", 15));
        repository.save(product("Office Backpack", "Water resistant laptop backpack", "Bags", "1999.00", 25));
    }

    private Product product(
        String name,
        String description,
        String category,
        String price,
        int stock
    ) {
        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setCategory(category);
        product.setPrice(new BigDecimal(price));
        product.setStockQuantity(stock);
        product.setImageUrl("https://placehold.co/600x400?text=Orbit+Product");
        product.setActive(true);
        return product;
    }
}
