package com.orbit.ecommerce.controller;

import com.orbit.ecommerce.dto.OrderDtos.OrderResponse;
import com.orbit.ecommerce.dto.OrderDtos.StatusRequest;
import com.orbit.ecommerce.model.OrderStatus;
import com.orbit.ecommerce.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin/orders")
public class AdminOrderController {

    private final OrderService orderService;

    public AdminOrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public List<OrderResponse> findAll() {
        return orderService.findAll();
    }

    @GetMapping("/status/{status}")
    public List<OrderResponse> findByStatus(@PathVariable OrderStatus status) {
        return orderService.findByStatus(status);
    }

    @PatchMapping("/{id}/status")
    public OrderResponse updateStatus(
        @PathVariable Long id,
        @Valid @RequestBody StatusRequest request
    ) {
        return orderService.updateStatus(id, request.status());
    }
}
