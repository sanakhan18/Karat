package com.orbit.ecommerce.service;

import com.orbit.ecommerce.dto.OrderDtos.OrderItemRequest;
import com.orbit.ecommerce.dto.OrderDtos.OrderItemResponse;
import com.orbit.ecommerce.dto.OrderDtos.OrderRequest;
import com.orbit.ecommerce.dto.OrderDtos.OrderResponse;
import com.orbit.ecommerce.exception.InsufficientStockException;
import com.orbit.ecommerce.exception.InvalidOrderException;
import com.orbit.ecommerce.exception.ResourceNotFoundException;
import com.orbit.ecommerce.exception.UnauthorizedException;
import com.orbit.ecommerce.model.Order;
import com.orbit.ecommerce.model.OrderItem;
import com.orbit.ecommerce.model.OrderStatus;
import com.orbit.ecommerce.model.Product;
import com.orbit.ecommerce.model.User;
import com.orbit.ecommerce.repository.OrderRepository;
import com.orbit.ecommerce.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final ProductService productService;

    public OrderService(
        OrderRepository orderRepository,
        UserRepository userRepository,
        ProductService productService
    ) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.productService = productService;
    }

    @Transactional
    public OrderResponse create(String email, OrderRequest request) {
        User user = findUser(email);
        Order order = new Order();
        order.setUser(user);
        order.setOrderNumber("ORB-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());

        BigDecimal total = BigDecimal.ZERO;
        for (OrderItemRequest itemRequest : request.items()) {
            Product product = productService.findEntity(itemRequest.productId());
            validateProduct(product, itemRequest.quantity());

            BigDecimal subtotal = product.getPrice()
                .multiply(BigDecimal.valueOf(itemRequest.quantity()));

            OrderItem item = new OrderItem();
            item.setProduct(product);
            item.setQuantity(itemRequest.quantity());
            item.setPrice(product.getPrice());
            item.setSubtotal(subtotal);
            order.addItem(item);

            product.setStockQuantity(product.getStockQuantity() - itemRequest.quantity());
            total = total.add(subtotal);
        }

        order.setTotalAmount(total);
        return toResponse(orderRepository.save(order));
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> findMine(String email) {
        User user = findUser(email);
        return orderRepository.findByUserIdOrderByCreatedAtDesc(user.getId())
            .stream()
            .map(this::toResponse)
            .toList();
    }

    @Transactional(readOnly = true)
    public OrderResponse findById(String email, Long id, boolean admin) {
        Order order = findEntity(id);
        if (!admin && !order.getUser().getEmail().equalsIgnoreCase(email)) {
            throw new UnauthorizedException("You cannot access this order");
        }
        return toResponse(order);
    }

    @Transactional
    public OrderResponse cancel(String email, Long id) {
        Order order = findEntity(id);
        if (!order.getUser().getEmail().equalsIgnoreCase(email)) {
            throw new UnauthorizedException("You cannot cancel this order");
        }
        if (order.getStatus() != OrderStatus.CREATED && order.getStatus() != OrderStatus.CONFIRMED) {
            throw new InvalidOrderException("Order cannot be cancelled now");
        }

        order.getItems().forEach(item -> {
            Product product = item.getProduct();
            product.setStockQuantity(product.getStockQuantity() + item.getQuantity());
        });
        order.setStatus(OrderStatus.CANCELLED);
        return toResponse(order);
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> findAll() {
        return orderRepository.findAllByOrderByCreatedAtDesc()
            .stream()
            .map(this::toResponse)
            .toList();
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> findByStatus(OrderStatus status) {
        return orderRepository.findByStatusOrderByCreatedAtDesc(status)
            .stream()
            .map(this::toResponse)
            .toList();
    }

    @Transactional
    public OrderResponse updateStatus(Long id, OrderStatus newStatus) {
        Order order = findEntity(id);
        if (!isValidTransition(order.getStatus(), newStatus)) {
            throw new InvalidOrderException("Invalid status transition");
        }
        order.setStatus(newStatus);
        return toResponse(order);
    }

    public Order findEntity(Long id) {
        return orderRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Order " + id + " not found"));
    }

    private User findUser(String email) {
        return userRepository.findByEmail(email.toLowerCase())
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    private void validateProduct(Product product, int quantity) {
        if (!product.isActive()) {
            throw new InvalidOrderException("Product is inactive: " + product.getName());
        }
        if (product.getStockQuantity() < quantity) {
            throw new InsufficientStockException("Insufficient stock for " + product.getName());
        }
    }

    private boolean isValidTransition(OrderStatus current, OrderStatus next) {
        return switch (current) {
            case CREATED -> next == OrderStatus.CONFIRMED || next == OrderStatus.CANCELLED;
            case CONFIRMED -> next == OrderStatus.PROCESSING || next == OrderStatus.CANCELLED;
            case PROCESSING -> next == OrderStatus.SHIPPED;
            case SHIPPED -> next == OrderStatus.DELIVERED;
            case DELIVERED, CANCELLED -> false;
        };
    }

    private OrderResponse toResponse(Order order) {
        List<OrderItemResponse> items = order.getItems().stream()
            .map(item -> new OrderItemResponse(
                item.getId(),
                item.getProduct().getId(),
                item.getProduct().getName(),
                item.getQuantity(),
                item.getPrice(),
                item.getSubtotal()
            ))
            .toList();

        return new OrderResponse(
            order.getId(),
            order.getOrderNumber(),
            order.getUser().getId(),
            order.getUser().getName(),
            order.getTotalAmount(),
            order.getStatus(),
            order.getCreatedAt(),
            order.getUpdatedAt(),
            items
        );
    }
}
