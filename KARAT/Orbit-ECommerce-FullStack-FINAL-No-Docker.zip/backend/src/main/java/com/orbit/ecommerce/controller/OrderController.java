package com.orbit.ecommerce.controller;

import com.orbit.ecommerce.dto.OrderDtos.OrderRequest;
import com.orbit.ecommerce.dto.OrderDtos.OrderResponse;
import com.orbit.ecommerce.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping
    public OrderResponse create(
        Authentication authentication,
        @Valid @RequestBody OrderRequest request
    ) {
        return orderService.create(authentication.getName(), request);
    }

    @GetMapping
    public List<OrderResponse> findMine(Authentication authentication) {
        return orderService.findMine(authentication.getName());
    }

    @GetMapping("/{id}")
    public OrderResponse findById(
        Authentication authentication,
        @PathVariable Long id
    ) {
        boolean admin = authentication.getAuthorities().stream()
            .anyMatch(authority -> authority.getAuthority().equals("ROLE_ADMIN"));
        return orderService.findById(authentication.getName(), id, admin);
    }

    @PatchMapping("/{id}/cancel")
    public OrderResponse cancel(
        Authentication authentication,
        @PathVariable Long id
    ) {
        return orderService.cancel(authentication.getName(), id);
    }
}
