import api from './api';

export async function createOrder(items) {
  return api.post('/orders', { items });
}

export async function getOrders() {
  return api.get('/orders');
}

export async function getOrder(id) {
  return api.get(`/orders/${id}`);
}

export async function cancelOrder(id) {
  return api.patch(`/orders/${id}/cancel`);
}

export async function createPayment(orderId, method) {
  return api.post('/payments', { orderId, method });
}
