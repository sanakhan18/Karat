import api from './api';

export async function getProducts() {
  return api.get('/products');
}

export async function getProduct(id) {
  return api.get(`/products/${id}`);
}

export async function searchProducts(query) {
  return api.get('/products/search', { params: { q: query } });
}

export async function getProductsByCategory(category) {
  return api.get(`/products/category/${encodeURIComponent(category)}`);
}
