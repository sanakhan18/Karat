import { createContext, useContext, useEffect, useState } from 'react';
import { getMe, login as loginRequest } from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('orbit_token');
    if (!token) {
      setLoading(false);
      return;
    }

    getMe()
      .then((response) => setUser(response.data))
      .catch(() => localStorage.removeItem('orbit_token'))
      .finally(() => setLoading(false));
  }, []);

  async function login(credentials) {
    const response = await loginRequest(credentials);
    localStorage.setItem('orbit_token', response.data.token);
    setUser({
      id: response.data.userId,
      name: response.data.name,
      email: response.data.email,
      role: response.data.role
    });
  }

  function logout() {
    localStorage.removeItem('orbit_token');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  return useContext(AuthContext);
}
