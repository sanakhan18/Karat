import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

export default function ProductCard({ product }) {
  const { addItem } = useCart();

  return (
    <article className="card">
      <img src={product.imageUrl} alt={product.name} />
      <div className="card-body">
        <span className="category">{product.category}</span>
        <h3>{product.name}</h3>
        <p>{product.description}</p>
        <strong>₹{Number(product.price).toLocaleString('en-IN')}</strong>
        <p>Stock: {product.stockQuantity}</p>
        <div className="actions">
          <Link className="button secondary" to={`/products/${product.id}`}>Details</Link>
          <button disabled={product.stockQuantity === 0} onClick={() => addItem(product)}>Add to Cart</button>
        </div>
      </div>
    </article>
  );
}
