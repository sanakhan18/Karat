import { useCart } from '../context/CartContext';

export default function CartItem({ item }) {
  const { updateQuantity, removeItem } = useCart();

  return (
    <div className="cart-item">
      <div>
        <h3>{item.name}</h3>
        <p>₹{Number(item.price).toLocaleString('en-IN')}</p>
      </div>
      <input
        type="number"
        min="1"
        max={item.stockQuantity}
        value={item.quantity}
        onChange={(event) => updateQuantity(item.id, Number(event.target.value))}
      />
      <strong>₹{(Number(item.price) * item.quantity).toLocaleString('en-IN')}</strong>
      <button className="danger" onClick={() => removeItem(item.id)}>Remove</button>
    </div>
  );
}
