import { Link, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';
import { useCart } from '../context/CartContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <nav className="navbar">
      <Link className="brand" to="/">Orbit</Link>
      <div className="nav-links">
        <Link to="/products">Products</Link>
        <Link to="/cart">Cart ({count})</Link>
        {user && <Link to="/orders">Orders</Link>}
        {user?.role === 'ADMIN' && <Link to="/admin">Admin</Link>}
        {user ? (
          <button onClick={handleLogout}>Logout</button>
        ) : (
          <Link to="/login">Login</Link>
        )}
      </div>
    </nav>
  );
}
