import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <section className="hero">
      <span>PROJECT ORBIT</span>
      <h1>Full-stack E-Commerce Portal</h1>
      <p>React + Spring Boot + JWT + API Gateway + H2</p>
      <Link className="button" to="/products">Shop Products</Link>
    </section>
  );
}
