import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Loading from '../components/Loading';
import { getOrders } from '../services/orderService';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getOrders()
      .then((response) => setOrders(response.data))
      .catch(() => setError('Unable to load orders'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loading />;

  return (
    <section>
      <h1>My Orders</h1>
      {error && <p className="error">{error}</p>}
      {orders.map((order) => (
        <article className="order-row" key={order.id}>
          <div>
            <strong>{order.orderNumber}</strong>
            <p>{new Date(order.createdAt).toLocaleString()}</p>
          </div>
          <span>{order.status}</span>
          <strong>₹{Number(order.totalAmount).toLocaleString('en-IN')}</strong>
          <Link className="button secondary" to={`/orders/${order.id}`}>Details</Link>
        </article>
      ))}
      {!orders.length && <p>No orders yet.</p>}
    </section>
  );
}
