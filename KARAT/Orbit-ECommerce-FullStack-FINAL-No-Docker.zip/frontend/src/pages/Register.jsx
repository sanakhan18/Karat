import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { register } from '../services/authService';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    if (form.password.length < 8) {
      setError('Password must contain at least 8 characters');
      return;
    }
    try {
      await register(form);
      navigate('/login');
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Registration failed');
    }
  }

  return (
    <section className="form-card">
      <h1>Create Account</h1>
      <form onSubmit={handleSubmit}>
        <label>Name<input value={form.name} onChange={(event) => update('name', event.target.value)} required /></label>
        <label>Email<input type="email" value={form.email} onChange={(event) => update('email', event.target.value)} required /></label>
        <label>Password<input type="password" value={form.password} onChange={(event) => update('password', event.target.value)} minLength="8" required /></label>
        {error && <p className="error">{error}</p>}
        <button>Register</button>
      </form>
      <p>Already registered? <Link to="/login">Login</Link></p>
    </section>
  );
}
