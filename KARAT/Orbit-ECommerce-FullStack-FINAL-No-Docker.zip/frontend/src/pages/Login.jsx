import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('customer@orbit.com');
  const [password, setPassword] = useState('Customer@123');
  const [error, setError] = useState('');

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    try {
      await login({ email, password });
      navigate(location.state?.from || '/products', { replace: true });
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Login failed');
    }
  }

  return (
    <section className="form-card">
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <label>Email<input value={email} onChange={(event) => setEmail(event.target.value)} type="email" required /></label>
        <label>Password<input value={password} onChange={(event) => setPassword(event.target.value)} type="password" required /></label>
        {error && <p className="error">{error}</p>}
        <button>Login</button>
      </form>
      <p>New customer? <Link to="/register">Register</Link></p>
      <p>Admin demo: admin@orbit.com / Admin@123</p>
    </section>
  );
}
