import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import Loading from '../components/Loading';
import { getProducts, searchProducts, getProductsByCategory } from '../services/productService';

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const search = searchParams.get('search') || '';
  const category = searchParams.get('category') || '';

  useEffect(() => {
    setLoading(true);
    setError('');
    const request = search
      ? searchProducts(search)
      : category
        ? getProductsByCategory(category)
        : getProducts();

    request
      .then((response) => setProducts(response.data))
      .catch(() => setError('Unable to load products'))
      .finally(() => setLoading(false));
  }, [search, category]);

  function handleSearch(event) {
    event.preventDefault();
    const value = event.currentTarget.elements.search.value.trim();
    if (value) {
      setSearchParams({ search: value });
    } else {
      setSearchParams({});
    }
  }

  if (loading) return <Loading />;

  return (
    <section>
      <div className="page-heading">
        <h1>Product Catalog</h1>
        <form onSubmit={handleSearch} className="search-form">
          <input name="search" defaultValue={search} placeholder="Search products" />
          <button>Search</button>
        </form>
      </div>
      {error && <p className="error">{error}</p>}
      <div className="grid">
        {products.map((product) => <ProductCard key={product.id} product={product} />)}
      </div>
      {!products.length && <p>No products found.</p>}
    </section>
  );
}
