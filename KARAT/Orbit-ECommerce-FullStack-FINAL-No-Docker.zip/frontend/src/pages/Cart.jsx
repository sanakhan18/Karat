import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CartItem from '../components/CartItem';
import useAuth from '../hooks/useAuth';
import { useCart } from '../context/CartContext';
import { createOrder, createPayment } from '../services/orderService';

export default function Cart() {
  const { user } = useAuth();
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function checkout() {
    if (!user) {
      navigate('/login', { state: { from: '/cart' } });
      return;
    }
    setBusy(true);
    setError('');
    try {
      const orderResponse = await createOrder(
        items.map((item) => ({ productId: item.id, quantity: item.quantity }))
      );
      await createPayment(orderResponse.data.id, 'CARD');
      clearCart();
      navigate(`/orders/${orderResponse.data.id}`);
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Checkout failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section>
      <h1>Cart</h1>
      {items.map((item) => <CartItem key={item.id} item={item} />)}
      {!items.length && <p>Your cart is empty.</p>}
      {items.length > 0 && (
        <div className="checkout">
          <h2>Total: ₹{total.toLocaleString('en-IN')}</h2>
          {error && <p className="error">{error}</p>}
          <button disabled={busy} onClick={checkout}>{busy ? 'Processing...' : 'Checkout'}</button>
        </div>
      )}
    </section>
  );
}
