import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Loading from '../components/Loading';
import { getOrder, cancelOrder } from '../services/orderService';

export default function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  function load() {
    setLoading(true);
    getOrder(id)
      .then((response) => setOrder(response.data))
      .catch((requestError) => setError(requestError.response?.data?.error || 'Unable to load order'))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, [id]);

  async function cancel() {
    try {
      await cancelOrder(id);
      load();
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Cancellation failed');
    }
  }

  if (loading) return <Loading />;
  if (!order) return <p className="error">{error}</p>;

  return (
    <section>
      <h1>{order.orderNumber}</h1>
      <p>Status: <strong>{order.status}</strong></p>
      <p>Date: {new Date(order.createdAt).toLocaleString()}</p>
      {order.items.map((item) => (
        <div className="order-item" key={item.id}>
          <span>{item.productName} × {item.quantity}</span>
          <span>₹{Number(item.subtotal).toLocaleString('en-IN')}</span>
        </div>
      ))}
      <h2>Total: ₹{Number(order.totalAmount).toLocaleString('en-IN')}</h2>
      {error && <p className="error">{error}</p>}
      {(order.status === 'CREATED' || order.status === 'CONFIRMED') && <button className="danger" onClick={cancel}>Cancel Order</button>}
    </section>
  );
}
