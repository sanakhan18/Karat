import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Loading from '../components/Loading';
import { getProduct } from '../services/productService';
import { useCart } from '../context/CartContext';

export default function ProductDetails() {
  const { id } = useParams();
  const { addItem } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    getProduct(id)
      .then((response) => setProduct(response.data))
      .catch(() => setError('Product not found'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Loading />;
  if (error) return <p className="error">{error}</p>;

  return (
    <section className="detail">
      <img src={product.imageUrl} alt={product.name} />
      <div>
        <span className="category">{product.category}</span>
        <h1>{product.name}</h1>
        <p>{product.description}</p>
        <h2>₹{Number(product.price).toLocaleString('en-IN')}</h2>
        <p>Available stock: {product.stockQuantity}</p>
        <button disabled={!product.stockQuantity} onClick={() => addItem(product)}>Add to Cart</button>
      </div>
    </section>
  );
}
