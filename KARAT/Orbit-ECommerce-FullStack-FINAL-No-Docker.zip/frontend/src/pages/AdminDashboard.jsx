import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';

export default function AdminDashboard() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [error, setError] = useState('');

  async function load() {
    try {
      const [productResponse, orderResponse, inventoryResponse] = await Promise.all([
        api.get('/products'),
        api.get('/admin/orders'),
        api.get('/inventory')
      ]);
      setProducts(productResponse.data);
      setOrders(orderResponse.data);
      setInventory(inventoryResponse.data);
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Unable to load admin data');
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function confirmOrder(id) {
    try {
      await api.patch(`/admin/orders/${id}/status`, { status: 'CONFIRMED' });
      load();
    } catch (requestError) {
      setError(requestError.response?.data?.error || 'Status update failed');
    }
  }

  return (
    <section>
      <h1>Admin Dashboard</h1>
      {error && <p className="error">{error}</p>}
      <h2>Products</h2>
      <p>{products.length} active products</p>
      <h2>Inventory</h2>
      <div className="table">
        {inventory.map((item) => <div key={item.productId}>{item.productName} — {item.stockQuantity} units</div>)}
      </div>
      <h2>Orders</h2>
      {orders.map((order) => (
        <div className="order-row" key={order.id}>
          <span>{order.orderNumber}</span>
          <span>{order.status}</span>
          <span>₹{Number(order.totalAmount).toLocaleString('en-IN')}</span>
          {order.status === 'CREATED' && <button onClick={() => confirmOrder(order.id)}>Confirm</button>}
          <Link className="button secondary" to={`/orders/${order.id}`}>View</Link>
        </div>
      ))}
    </section>
  );
}
