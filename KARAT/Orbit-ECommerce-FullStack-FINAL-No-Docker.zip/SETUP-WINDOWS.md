# Windows setup

## Java

Install JDK 17 or newer and install the VS Code Extension Pack for Java.

Open the project root in VS Code. Wait until Maven projects finish loading.

## Backend

Open `backend/src/main/java/com/orbit/ecommerce/OrbitEcommerceApplication.java` and select Run Java.

Backend URL: http://localhost:8081

## Gateway

Open `api-gateway/src/main/java/com/orbit/gateway/ApiGatewayApplication.java` and select Run Java.

Gateway URL: http://localhost:8080

## Frontend

Open a terminal in `frontend`:

```text
npm install
npm run dev
```

Open http://localhost:5173

Do not run `mvn` from PowerShell unless Maven is separately installed. VS Code can run the Spring Boot main class directly.
