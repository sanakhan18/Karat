package com.orbit.ecommerce.exception; public class InvalidOrderException extends RuntimeException{public InvalidOrderException(String m){super(m);}}
