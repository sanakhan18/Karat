package com.orbit.ecommerce.exception; public class InsufficientStockException extends RuntimeException{public InsufficientStockException(String m){super(m);}}
