package com.orbit.ecommerce.exception; public final class Exceptions{private Exceptions(){}} 
