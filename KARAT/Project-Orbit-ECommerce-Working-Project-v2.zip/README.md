# Project Orbit — working full-stack project

Based on the supplied Project Orbit specification. It implements the initial runnable Spring Boot architecture with the service separation needed for later API Gateway/microservice extraction.

## Run in VS Code
1. Install Java 17+, Maven, Node.js 20+, npm and Docker Desktop.
2. Open this folder in VS Code.
3. Terminal 1: `docker compose up -d`
4. Terminal 2: `cd backend && mvn spring-boot:run`
5. Terminal 3: `cd frontend && npm install && npm run dev`
6. Open http://localhost:5173

## Default admin
Email: admin@orbit.com
Password: Admin@123

## API
Base: http://localhost:8080
Protected requests require `Authorization: Bearer <JWT>`.

Auth: POST /api/auth/register, POST /api/auth/login, GET /api/auth/me
Products: GET /api/products, GET /api/products/{id}, GET /api/products/search?q=laptop, GET /api/products/category/Electronics, POST/PUT/DELETE /api/products..., PATCH activate/deactivate
Orders: POST /api/orders, GET /api/orders, GET /api/orders/{id}, PATCH /api/orders/{id}/cancel
Admin orders: GET /api/admin/orders, GET /api/admin/orders/status/{status}, PATCH /api/admin/orders/{id}/status
Inventory: GET /api/inventory, GET /api/inventory/{id}, POST /api/inventory?productId=1, PUT /api/inventory/{id}, PATCH increase/decrease
Payment: POST /api/payments, GET /api/payments/{id}, GET /api/orders/{id}/payment, POST /api/payments/{id}/refund
Notification: POST /api/notifications, GET /api/notifications/{id}, GET /api/notifications/user/{userId}

## Customer API test sequence
1. Register.
2. Login and copy token.
3. GET /api/products.
4. POST /api/orders with `{ "items": [{"productId":1,"quantity":1}] }`.
5. POST /api/payments with `{ "orderId":1,"method":"MOCK_CARD" }`.
6. GET /api/orders.
7. PATCH /api/orders/1/cancel if status is CREATED/CONFIRMED.

## Admin API test sequence
1. Login with admin credentials.
2. Replace Bearer token with admin JWT.
3. POST /api/products to create a product.
4. PUT/PATCH product to edit/activate/deactivate.
5. GET /api/inventory and change stock.
6. GET /api/admin/orders.
7. Advance an order CREATED -> CONFIRMED -> PROCESSING -> SHIPPED -> DELIVERED.
8. Try an invalid transition to verify business validation.

## Frontend notes
Cart is browser localStorage because the supplied API catalogue has no Cart endpoint. Checkout converts cart lines to the server-side OrderRequest. Payment is intentionally mock, as permitted by the specification.
