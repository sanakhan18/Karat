import {Link} from 'react-router-dom';export default function NotFound(){return <section><h2>404</h2><Link to="/">Home</Link></section>}
