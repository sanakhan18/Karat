import api from './api';export const register=x=>api.post('/api/auth/register',x);export const login=x=>api.post('/api/auth/login',x);export const me=()=>api.get('/api/auth/me');
